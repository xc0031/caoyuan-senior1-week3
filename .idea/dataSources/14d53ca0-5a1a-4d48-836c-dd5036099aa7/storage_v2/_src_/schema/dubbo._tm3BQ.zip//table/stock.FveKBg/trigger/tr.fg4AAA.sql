create trigger tr
  after UPDATE
  on stock
  for each row
BEGIN
	set @num = (select number from `order` where gid = old.gid);
	set @cayi = old.number-new.number;
	
END;

